package com.class_test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
