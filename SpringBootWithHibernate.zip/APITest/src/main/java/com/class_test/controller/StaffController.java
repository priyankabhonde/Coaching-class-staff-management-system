package com.class_test.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.class_test.service.StaffService;
import com.class_test.staffentity.Staff;

@RestController
public class StaffController {
	@Autowired
	StaffService ss;
	
	@PostMapping("/inserstaffrecord")
	String insertstaff(@RequestBody List<Staff> staff) {
		String msg = ss.insertstaff(staff);
		return msg;
	}
	
	@GetMapping("/getallstaffrecord")
	List<Staff> getallstaffrecord(){
		List<Staff> staff = ss.getallstaffrecord();
		return staff;
	}
	
	@GetMapping("/byidstaffrecord/{id}")
	List<Staff> byidstaffrecord(@PathVariable int id){
		List<Staff> staff = ss.byidstaffrecord(id);
		return staff;
	}
	
	@GetMapping("/salary2KMore")
	List<Staff> salarymore2k(){
	List<Staff> staff = ss.salarymore2k();
	return staff;
	}
	
	@GetMapping("/btwn")
	List<Staff>experiencebtwn10yto20y(){
		List<Staff> staff = ss.experiencebtwn10yto20y();
		return staff;
	}
	
	@GetMapping("/maxsal")
	List<Staff> maxsalary(){
		List<Staff> staff = ss.maxsalary();
		return staff;
	}
	
	@PutMapping("/updatesal")
	String updatesalary(@RequestBody Staff s) {
		String msg = ss.updatesalary(s);
		return msg;
	}
	
	
	@GetMapping("/profile/{trainer}")
	public List<Staff> trainer(@PathVariable String trainer) {
		List<Staff> staff = ss.trainer(trainer);
		return staff;

	}

	@GetMapping("/nprofile/{trainer}")
	public List<Staff> ntrainer(@PathVariable String trainer) {
		List<Staff> staff = ss.ntrainer(trainer);
		return staff;

	}
	

}
