package com.class_test.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.class_test.dao.StaffDao;
import com.class_test.staffentity.Staff;

@Service
public class StaffService {
	@Autowired
	StaffDao sd;
	
	public String insertstaff(List<Staff> staff) {
	String msg = sd.insertstaff(staff);
	return msg;
	}
	
	public List<Staff> getallstaffrecord(){
		List<Staff> staff = sd.getallstaffrecord();
		return staff;
	}
	
	public List<Staff> byidstaffrecord(int id){
		List<Staff> staff = sd.byidstaffrecord(id);
		return staff;
	}
	
	public List<Staff> salarymore2k(){
		List<Staff> staff = sd.salarymore2k();
		return staff;
	}
	
	public List<Staff> experiencebtwn10yto20y(){
		List<Staff> staff = sd.experiencebtwn10yto20y();
		return staff;
	}
	
	public List<Staff> maxsalary(){
		List<Staff> staff  = sd.maxsalary();
		return staff;
	}
	
	public String updatesalary(Staff s){
		String msg = sd.updatesalary(s);
		return msg;
		
	}
	
	public List<Staff> trainer(String trainer) {
		List<Staff> staff = sd.trainer(trainer);
		return staff;
	}

	public List<Staff> ntrainer(String trainer) {
		List<Staff> staff = sd.ntrainer(trainer);
		return staff;
	}


}
