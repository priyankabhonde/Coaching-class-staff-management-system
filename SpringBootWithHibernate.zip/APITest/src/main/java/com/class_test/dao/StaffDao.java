package com.class_test.dao;

import java.util.Collections;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.class_test.staffentity.Staff;
@Repository
public class StaffDao {
	  @Autowired
      SessionFactory sf;
//	  Write an api to insert all staff record.
	public String insertstaff(List<Staff> staff) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		for (Staff staff2 : staff) {
			session.save(staff2);
			
		}
		tr.commit();
		session.close();
		return "Staff record inserted successfully";
	}
	
//	Write an api to get all the staff record.
	
	public List<Staff> getallstaffrecord() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		List<Staff> staff = criteria.list();
		for (Staff staff2 : staff) {
			System.out.println(staff2);
			
		}
		return staff;
		
	}
	
//	Write an api to get record whose staffid is 3.
	
	public List<Staff> byidstaffrecord(int id){
	Session session = sf.openSession();
	Criteria criteria = session.createCriteria(Staff.class);
	criteria.add(Restrictions.eq("id",id));
	List<Staff> staff = criteria.list();
	for (Staff staff2 : staff) {
		System.out.println(staff2);
		
	}
	return staff;
	}
	
//	Write an api to get the list of staff who is salary more than 20000.
	
	public List<Staff> salarymore2k(){
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		criteria.add(Restrictions.gt("salary", "20000"));
		List<Staff> staff = criteria.list();
		return staff;
	}
	
//	Write an api to get the list of staff who are having the experience between 10 to 20.
	
	public List<Staff> experiencebtwn10yto20y(){
	Session session = sf.openSession();
	Criteria criteria = session.createCriteria(Staff.class);
	criteria.add(Restrictions.between("experience", "10", "20"));
	List<Staff> staff = criteria.list();
	return staff;
	}
	
	//Write an api to get staff information who is having max salary.
	
	public List<Staff> maxsalary(){
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		criteria.addOrder(Order.desc("salary"));
		
		List<Staff> staff = criteria.list();
		for (Staff staff2 : staff) {
		String salary = staff2.getSalary();
	}
		return staff;
	}
	
	// Write an api to update the salary for staff whose id is 4.
	
	public String updatesalary(Staff s){
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.update(s);
		tr.commit();
		return "Update Success";
	}
	
//	Write an api to get the staff name who is having minimun experience.
	
//	Write an api to get the list of staff whose are having profile as trainer.
	
	public List<Staff> trainer(String trainer) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		criteria.add(Restrictions.eq("profile", "trainer"));
		List<Staff> staff = criteria.list();
		return staff;
	}
	
//	Write an api to get the list of staff whose are not having profile as trainer.
	
	public List<Staff> ntrainer(String trainer) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Staff.class);
		criteria.add(Restrictions.ne("profile", "trainer"));
		List<Staff> staff = criteria.list();
		return staff;
	}


	
	
	
	
	
	
	

}
